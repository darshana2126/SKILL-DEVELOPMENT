import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Room } from "./room/room";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Room],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('dependence');
}
