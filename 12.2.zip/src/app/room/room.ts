import { Component } from '@angular/core';
import { Ac } from './ac';

@Component({
  selector: 'app-room',
  imports: [],
  templateUrl: './room.html',
  styleUrl: './room.css',
})
export class Room {
  message:string='';
  constructor(private ac:Ac){}
onac(){
  this.message=this.ac.turnOn();
}
offac(){
  this.message=this.ac.turnOff();
}
}