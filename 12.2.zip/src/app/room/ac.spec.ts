import { TestBed } from '@angular/core/testing';

import { Ac } from './ac';

describe('Ac', () => {
  let service: Ac;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Ac);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
