import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class Ac {
  
  turnOn(){
    return 'AC is turned on';
  }
  turnOff(){
    return 'AC is turned off';
  }
  
}
