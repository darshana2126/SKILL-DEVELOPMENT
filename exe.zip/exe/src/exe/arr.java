package exe;

public class arr {

	public static void main(String[] args) {

		try {
			int a[]= {10,20,30};
			System.out.println(a[0]);
			System.out.println(a[1]);
			System.out.println(a[2]);
		//	System.out.println(a[3]);

		} catch (Exception e) {
			System.out.println("sdgvx"+e);
			
		}
		
		System.out.println("vsvfb");
		}
		}