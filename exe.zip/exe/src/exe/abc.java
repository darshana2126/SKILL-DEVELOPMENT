package exe;

public class abc {

	public static void main(String[] args) {

	try {
		System.out.println("awff");
		System.out.println("fsdvxd");
		System.out.println("dvxfb");
		
		System.out.println(10/0);
		
		System.out.println("dvxv");
		System.out.println("dvdx");
		
	} catch (Exception e) {
		System.out.println("sdgvx"+e);
		
	}
	System.out.println("vsvfb");
	}
	}
	
