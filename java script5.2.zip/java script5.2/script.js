function validateform() {
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if (username=="hi") {
        alert("username correct");
        
         }
    else{
    alert("username wrong")
        }
    if (username=="hi" && password=="bye") {
        alert("password correct");
        window.location.href="dottedbor.html";
        return false;
        
    }
    else{
    alert("password wrong")
     }
}