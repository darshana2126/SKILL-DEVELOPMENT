import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-data-binding',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './data-binding.html',
  styleUrl: './data-binding.css',
})
export class DataBinding  {

  // string interpolation example
  name="Tamil Nadu";

  // property binding example
  isdisabled = false;
  // event binding example
  enablebutton(){
    this.isdisabled = true;

  }
  // two way binding example
   username = '';
   showalert(){
    alert("Hello " + this.username);
    }
  }