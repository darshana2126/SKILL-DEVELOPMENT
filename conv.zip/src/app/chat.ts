
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Message } from './message/message';

@Injectable({ providedIn: 'root' })
export class ChatService {
  private chatMessages: Message[] = [];
  private users = ['Poona', 'Ranjith', 'Vicky'];
  private currentUser = 'Poona';
  
  private messageSource = new BehaviorSubject<Message[]>([]);
  private userSource = new BehaviorSubject<string>(this.currentUser);
  private usersListSource = new BehaviorSubject<string[]>(this.users);
  
  messages$ = this.messageSource.asObservable();
  currentUser$ = this.userSource.asObservable();
  usersList$ = this.usersListSource.asObservable();

  setCurrentUser(user: string) {
    this.currentUser = user;
    this.userSource.next(user);
  }

  addMessage(user: string, text: string) {
    const newMessage: Message = { user, text, time: new Date(), groupId: '' };
    this.chatMessages.push(newMessage);
    this.messageSource.next(this.chatMessages); 
  }
}