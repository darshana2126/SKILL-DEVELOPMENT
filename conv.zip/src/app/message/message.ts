export interface Message {
  user: string;
  text: string;
  time: Date;
  groupId: string;
}

export interface Group {
  id: string;
  name: string;
  members: string[];
}