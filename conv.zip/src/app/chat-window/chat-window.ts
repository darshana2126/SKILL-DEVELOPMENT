import { Component } from '@angular/core';
import { ChatService } from '../chat';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-chat',
  imports: [FormsModule, DatePipe],
  templateUrl: './chat-window.html',
  styleUrls: ['./chat-window.css']
})
export class ChatComponent {
  msgList: any[] = [];
  userInput: string = '';
  currentUser: string = 'Poona';
  users: string[] = ['Poona', 'Ranjith', 'Vicky'];

  constructor(private chatService: ChatService) {
   
    this.chatService.messages$.subscribe(data => this.msgList = data);
    this.chatService.currentUser$.subscribe(user => this.currentUser = user);
  }

  selectUser(user: string) {
    this.chatService.setCurrentUser(user);
  }

  sendMessage() {
    if (this.userInput.trim()) {
      this.chatService.addMessage(this.currentUser, this.userInput);
      this.userInput = ''; 
    }
  }
}