import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Withdraw } from './withdraw/withdraw';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Withdraw],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('darshana');

  message = "Hello, darshana";

  changemessage() {
    this.message = 'Welcome to darshana';
  }
}