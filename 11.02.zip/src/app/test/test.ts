import { Component } from '@angular/core';

@Component({
  selector: 'app-test',
  imports: [],
  templateUrl: './test.html',
  styleUrl: './test.css',
})
export class Test {
name:string = "darshana";
course:string = "angular tranning";
fees:number = 10000;
}
