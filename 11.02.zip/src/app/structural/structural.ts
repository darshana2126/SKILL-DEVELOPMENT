import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-structural',
  imports: [CommonModule],
  templateUrl: './structural.html',
  styleUrl: './structural.css',
})
export class Structural {
// ---------- ngif
isloggedin:boolean = false;

login(){
  this.isloggedin = true;
  
}
logout(){
  this.isloggedin = false;

}

//-------ngfor 
courses:string[] = ['Angular','React','javascript','node'];

///-------ngSwitch
  color:string = 'red'; 
  setColor(col:string){
    this.color = col;
  }

}